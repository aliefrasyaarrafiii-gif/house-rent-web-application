const bookingSchema = require("../models/BookingSchema");
const propertySchema = require("../models/PropertySchema");
const userSchema = require("../models/UserSchema");

const addPropertyController = async (req, res) => {
  try {
    let images = [];
    if (req.files) {
      images = req.files.map((file) => ({
        filename: file.filename,
        path: `/uploads/${file.filename}`,
      }));
    }

    const user = await userSchema.findById({ _id: req.body.userId });

    const newPropertyData = new propertySchema({
      ...req.body,
      propertyImage: images,
      ownerId: user._id,
      ownerName: user.name,
      isAvailable: "Available",
    });

    await newPropertyData.save();

    return res.status(200).send({
      message: "Properti berhasil ditambahkan!",
      success: true,
    });
  } catch (error) {
    console.log("Error saat menambah properti:", error);
    return res.status(500).send({
      message: "Gagal menambahkan properti",
      success: false,
    });
  }
};

const getAllOwnerPropertiesController = async (req, res) => {
  const { userId } = req.body;
  try {
    const getAllProperties = await propertySchema.find({ ownerId: userId });
    return res.status(200).send({
      success: true,
      data: getAllProperties,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).send({
      message: "Gagal mengambil data properti milik owner",
      success: false,
    });
  }
};

const deletePropertyController = async (req, res) => {
  const { propertyid } = req.params;
  try {
    await propertySchema.findByIdAndDelete({ _id: propertyid });
    return res.status(200).send({
      message: "Properti berhasil dihapus",
      success: true,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).send({
      message: "Gagal menghapus properti",
      success: false,
    });
  }
};

const updatePropertyController = async (req, res) => {
  const { propertyid } = req.params;
  try {
    await propertySchema.findByIdAndUpdate(
      { _id: propertyid },
      { ...req.body },
      { new: true }
    );
    return res.status(200).send({
      message: "Data properti berhasil diperbarui",
      success: true,
    });
  } catch (error) {
    console.error("Error updating property:", error);
    return res.status(500).send({
      message: "Gagal memperbarui properti",
      success: false,
    });
  }
};

const getAllBookingsController = async (req, res) => {
  const { userId } = req.body;
  try {
    const getAllBookings = await bookingSchema.find({ ownerID: userId });
    return res.status(200).send({
      success: true,
      data: getAllBookings,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).send({
      message: "Gagal mengambil daftar booking",
      success: false,
    });
  }
};

const handleAllBookingstatusController = async (req, res) => {
  const { bookingId, propertyId, status } = req.body;
  try {
    await bookingSchema.findByIdAndUpdate(
      { _id: bookingId },
      { bookingStatus: status },
      { new: true }
    );

    await propertySchema.findByIdAndUpdate(
      { _id: propertyId },
      { isAvailable: status === "booked" ? "Unavailable" : "Available" },
      { new: true }
    );

    return res.status(200).send({
      success: true,
      message: `Status booking berhasil diubah menjadi ${status}`,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).send({
      message: "Gagal mengubah status booking",
      success: false,
    });
  }
};

module.exports = {
  addPropertyController,
  getAllOwnerPropertiesController,
  deletePropertyController,
  updatePropertyController,
  getAllBookingsController,
  handleAllBookingstatusController,
};
