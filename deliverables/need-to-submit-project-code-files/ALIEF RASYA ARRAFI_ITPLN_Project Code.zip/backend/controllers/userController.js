const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const userSchema = require("../models/UserSchema");
const propertySchema = require("../models/PropertySchema");
const bookingSchema = require("../models/BookingSchema");

const registerController = async (req, res) => {
  try {
    const existsUser = await userSchema.findOne({ email: req.body.email });
    if (existsUser) {
      return res
        .status(200)
        .send({ message: "Email sudah terdaftar", success: false });
    }

    const password = req.body.password;
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    req.body.password = hashedPassword;

    if (req.body.type === "Owner") {
      req.body.granted = "ungranted";
    } else {
      req.body.granted = "granted";
    }

    const newUser = new userSchema(req.body);
    await newUser.save();

    return res.status(201).send({
      message: "Registrasi berhasil!",
      success: true,
    });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .send({ success: false, message: `Error saat registrasi: ${error.message}` });
  }
};

const loginController = async (req, res) => {
  try {
    const user = await userSchema.findOne({ email: req.body.email });
    if (!user) {
      return res
        .status(200)
        .send({ message: "Pengguna tidak ditemukan", success: false });
    }

    const isMatch = await bcrypt.compare(req.body.password, user.password);
    if (!isMatch) {
      return res
        .status(200)
        .send({ message: "Email atau password salah", success: false });
    }

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });

    user.password = undefined;
    return res.status(200).send({
      message: "Login berhasil",
      success: true,
      token,
      user,
    });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .send({ success: false, message: `Error saat login: ${error.message}` });
  }
};

const getAllPropertiesController = async (req, res) => {
  try {
    const allProperties = await propertySchema.find({});
    if (!allProperties) {
      return res.status(404).send({ message: "Belum ada properti tersedia", success: false });
    }
    return res.status(200).send({
      success: true,
      data: allProperties,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ message: "Gagal mengambil data properti", success: false });
  }
};

const bookingHandleController = async (req, res) => {
  const { propertyId } = req.params;
  const { userDetails, status, userId, ownerId } = req.body;

  try {
    const booking = new bookingSchema({
      propertyId,
      userID: userId,
      ownerID: ownerId,
      userName: userDetails.fullName,
      phone: userDetails.phone,
      bookingStatus: status || "pending",
    });

    await booking.save();

    return res.status(200).send({
      success: true,
      message: "Booking berhasil diajukan! Menunggu konfirmasi pemilik.",
    });
  } catch (error) {
    console.error("Error booking:", error);
    return res.status(500).send({
      success: false,
      message: "Gagal memproses booking",
    });
  }
};

const getAllBookingsController = async (req, res) => {
  const { userId } = req.body;
  try {
    const getAllBookings = await bookingSchema.find({ userID: userId });
    return res.status(200).send({
      success: true,
      data: getAllBookings,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).send({
      message: "Gagal mengambil riwayat booking",
      success: false,
    });
  }
};

module.exports = {
  registerController,
  loginController,
  getAllPropertiesController,
  bookingHandleController,
  getAllBookingsController,
};
