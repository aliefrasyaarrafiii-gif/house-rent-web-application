const propertySchema = require("../models/PropertySchema");
const userSchema = require("../models/UserSchema");
const bookingSchema = require("../models/BookingSchema");

const getAllUsersController = async (req, res) => {
  try {
    const allUsers = await userSchema.find({});
    return res.status(200).send({
      success: true,
      data: allUsers,
    });
  } catch (error) {
    console.log("Error getAllUsers:", error);
    return res.status(500).send({
      success: false,
      message: "Gagal mengambil data semua pengguna",
    });
  }
};

const handleStatusController = async (req, res) => {
  const { userid, status } = req.body;
  try {
    await userSchema.findByIdAndUpdate(
      userid,
      { granted: status },
      { new: true }
    );
    return res.status(200).send({
      success: true,
      message: `Status akun owner berhasil diubah menjadi ${status}`,
    });
  } catch (error) {
    console.log("Error handleStatus:", error);
    return res.status(500).send({
      success: false,
      message: "Gagal mengubah status pengguna",
    });
  }
};

const getAllPropertiesController = async (req, res) => {
  try {
    const allProperties = await propertySchema.find({});
    return res.status(200).send({
      success: true,
      data: allProperties,
    });
  } catch (error) {
    console.log("Error getAllProperties:", error);
    return res.status(500).send({
      success: false,
      message: "Gagal mengambil semua properti",
    });
  }
};

const getAllBookingsController = async (req, res) => {
  try {
    const allBookings = await bookingSchema.find({});
    return res.status(200).send({
      success: true,
      data: allBookings,
    });
  } catch (error) {
    console.log("Error getAllBookings:", error);
    return res.status(500).send({
      success: false,
      message: "Gagal mengambil semua data booking",
    });
  }
};

module.exports = {
  getAllUsersController,
  handleStatusController,
  getAllPropertiesController,
  getAllBookingsController,
};
