const express = require("express");
const authMiddleware = require("../middlewares/authMiddleware");
const {
  registerController,
  loginController,
  getAllPropertiesController,
  bookingHandleController,
  getAllBookingsController,
} = require("../controllers/userController");

const router = express.Router();

router.post("/register", registerController);
router.post("/login", loginController);
router.get("/getAllProperties", getAllPropertiesController);
router.post("/bookinghandle/:propertyId", authMiddleware, bookingHandleController);
router.get("/getallbookings", authMiddleware, getAllBookingsController);

module.exports = router;
