const express = require("express");
const multer = require("multer");
const authMiddleware = require("../middlewares/authMiddleware");
const {
  addPropertyController,
  getAllOwnerPropertiesController,
  deletePropertyController,
  updatePropertyController,
  getAllBookingsController,
  handleAllBookingstatusController,
} = require("../controllers/ownerController");

const router = express.Router();

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({ storage: storage });

router.post(
  "/postproperty",
  upload.array("propertyImages"),
  authMiddleware,
  addPropertyController
);
router.get("/getallproperties", authMiddleware, getAllOwnerPropertiesController);
router.delete("/deleteproperty/:propertyid", authMiddleware, deletePropertyController);
router.patch("/updateproperty/:propertyid", authMiddleware, updatePropertyController);
router.get("/getallbookings", authMiddleware, getAllBookingsController);
router.post("/handlebookingstatus", authMiddleware, handleAllBookingstatusController);

module.exports = router;
