const jwt = require("jsonwebtoken");

module.exports = async (req, res, next) => {
  try {
    const authorizationHeader = req.headers["authorization"];
    if (!authorizationHeader) {
      return res.status(401).send({
        message: "Token autentikasi tidak ditemukan",
        success: false,
      });
    }

    const token = authorizationHeader.split(" ")[1];
    jwt.verify(token, process.env.JWT_SECRET, (err, decode) => {
      if (err) {
        return res.status(401).send({
          message: "Token tidak valid atau sudah kedaluwarsa",
          success: false,
        });
      } else {
        req.body = req.body || {};
        req.body.userId = decode.id;
        next();
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).send({
      message: "Terjadi kesalahan pada autentikasi server",
      success: false,
    });
  }
};
