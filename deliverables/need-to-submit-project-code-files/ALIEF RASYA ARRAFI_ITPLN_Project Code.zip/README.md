# RentEase (HouseRent) - MERN Stack Home Rental Web Application

RentEase is a full-stack home rental web application built using the **MERN Stack** (MongoDB, Express.js, React.js, and Node.js). It connects property owners and renters seamlessly while providing administrative oversight.

## Key Features
- **Role-Based Access Control (RBAC):** Supports three distinct user roles (**Admin**, **Owner**, and **Renter**) secured with JWT authentication and `bcryptjs` password hashing.
- **Admin Dashboard:** View all registered users, approve/revoke property owner permissions (`Grant` / `Ungrant`), and monitor all properties and bookings across the platform.
- **Owner Dashboard:** Approved owners can add new properties with image uploads (`Multer`), manage property availability (`Available` / `Unavailable`), delete listings, and confirm or revert tenant booking requests (`Mark Booked` / `Mark Pending`).
- **Renter Dashboard:** Browse available properties, filter by address, ad type (`Rent` / `Sale`), and property type (`Residential` / `Commercial`), view owner contact details, submit booking requests, and track booking status history.

## Project Structure
```
HOUSERENT/
├── backend/
│   ├── config/          # MongoDB connection (connect.js)
│   ├── controllers/     # Business logic for Admin, Owner, and User/Renter
│   ├── middlewares/     # JWT authentication middleware (authMiddleware.js)
│   ├── models/          # Mongoose schemas (UserSchema, PropertySchema, BookingSchema)
│   ├── routes/          # Express API routes
│   ├── uploads/         # Uploaded property images directory
│   ├── .env.example     # Environment variables template
│   ├── index.js         # Express server entry point
│   └── package.json
└── frontend/
    ├── src/
    │   ├── modules/
    │   │   ├── admin/   # AdminHome, AllUsers, AllProperty, AllBookings
    │   │   ├── common/  # Home, Login, Register, ForgotPassword, Toast
    │   │   └── user/    # AllPropertiesCards, owner/*, renter/*
    │   ├── App.css      # Custom dark theme styling
    │   ├── App.jsx      # React Router & Context setup
    │   └── main.jsx
    ├── index.html
    └── package.json
```

## Setup & Installation
1. **Backend Setup:**
   ```bash
   cd backend
   npm install
   cp .env.example .env
   # Update MONGO_URI and JWT_SECRET in .env
   npm run dev
   ```
2. **Frontend Setup:**
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
3. Open `http://localhost:5173` in your browser.
