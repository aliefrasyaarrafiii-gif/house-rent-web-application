import React, { useState } from "react";
import { Link } from "react-router-dom";
import Toast from "./Toast";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [toast, setToast] = useState({ type: "", message: "" });

  const handleSubmit = (e) => {
    e.preventDefault();
    setToast({
      type: "success",
      message: "Instruksi reset password telah dikirim ke email Anda.",
    });
    setEmail("");
  };

  return (
    <div>
      <Toast
        type={toast.type}
        message={toast.message}
        onClose={() => setToast({ type: "", message: "" })}
      />
      <nav className="navbar navbar-expand-lg navbar-custom">
        <div className="container-fluid">
          <Link className="brand-title" to="/">
            RentEase
          </Link>
          <div className="d-flex align-items-center gap-3">
            <Link className="text-light text-decoration-none" to="/">
              Home
            </Link>
            <Link className="text-light text-decoration-none" to="/login">
              Login
            </Link>
          </div>
        </div>
      </nav>

      <div className="container d-flex justify-content-center align-items-center" style={{ minHeight: "85vh" }}>
        <div className="card card-dark p-4 shadow" style={{ width: "100%", maxWidth: "420px" }}>
          <h3 className="text-center fw-bold mb-3">Reset Password</h3>
          <p className="text-secondary text-center small mb-4">
            Masukkan email terdaftar untuk mereset kata sandi akun Anda.
          </p>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <input
                type="email"
                required
                className="form-control form-control-dark"
                placeholder="Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <button type="submit" className="btn btn-purple w-100 py-2">
              Send Reset Link
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
