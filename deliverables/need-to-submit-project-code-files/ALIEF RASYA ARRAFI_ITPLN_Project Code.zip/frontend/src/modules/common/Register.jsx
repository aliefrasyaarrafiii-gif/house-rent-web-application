import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import Toast from "./Toast";

const Register = () => {
  const navigate = useNavigate();
  const [data, setData] = useState({
    name: "",
    email: "",
    password: "",
    type: "",
  });
  const [toast, setToast] = useState({ type: "", message: "" });

  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!data.type) {
      return setToast({ type: "error", message: "Pilih tipe user terlebih dahulu" });
    }
    try {
      const res = await axios.post("http://localhost:8000/api/user/register", data);
      if (res.data.success) {
        setToast({ type: "success", message: res.data.message });
        setTimeout(() => navigate("/login"), 1200);
      } else {
        setToast({ type: "error", message: res.data.message });
      }
    } catch (error) {
      console.log(error);
      setToast({ type: "error", message: "Terjadi kesalahan saat registrasi" });
    }
  };

  return (
    <div>
      <Toast
        type={toast.type}
        message={toast.message}
        onClose={() => setToast({ type: "", message: "" })}
      />
      <nav className="navbar navbar-expand-lg navbar-custom">
        <div className="container-fluid">
          <Link className="brand-title" to="/">
            RentEase
          </Link>
          <div className="d-flex align-items-center gap-3">
            <Link className="text-light text-decoration-none" to="/">
              Home
            </Link>
            <Link className="text-light text-decoration-none" to="/login">
              Login
            </Link>
            <Link className="btn btn-purple px-3" to="/register">
              Register
            </Link>
          </div>
        </div>
      </nav>

      <div className="container d-flex justify-content-center align-items-center" style={{ minHeight: "85vh" }}>
        <div className="card card-dark p-4 shadow" style={{ width: "100%", maxWidth: "420px" }}>
          <h3 className="text-center fw-bold mb-4">Sign Up</h3>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <input
                type="text"
                name="name"
                required
                className="form-control form-control-dark"
                placeholder="Renter Full Name / Owner Name"
                value={data.name}
                onChange={handleChange}
              />
            </div>
            <div className="mb-3">
              <input
                type="email"
                name="email"
                required
                className="form-control form-control-dark"
                placeholder="Email Address"
                value={data.email}
                onChange={handleChange}
              />
            </div>
            <div className="mb-3">
              <input
                type="password"
                name="password"
                required
                className="form-control form-control-dark"
                placeholder="Password"
                value={data.password}
                onChange={handleChange}
              />
            </div>
            <div className="mb-4">
              <select
                name="type"
                required
                className="form-select form-select-dark"
                value={data.type}
                onChange={handleChange}
              >
                <option value="">Select User Type</option>
                <option value="Renter">Renter</option>
                <option value="Owner">Owner</option>
                <option value="Admin">Admin</option>
              </select>
            </div>
            <button type="submit" className="btn btn-purple w-100 py-2">
              Sign Up
            </button>
          </form>
          <p className="text-center text-secondary mt-3 mb-0 small">
            Have an account?{" "}
            <Link to="/login" className="text-primary text-decoration-none">
              Sign In
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;
