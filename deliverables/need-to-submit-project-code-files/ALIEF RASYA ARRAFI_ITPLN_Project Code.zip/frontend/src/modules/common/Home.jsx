import React from "react";
import { Link } from "react-router-dom";
import AllPropertiesCards from "../user/AllPropertiesCards";

const Home = () => {
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-custom">
        <div className="container-fluid">
          <Link className="brand-title" to="/">
            RentEase
          </Link>
          <div className="d-flex align-items-center gap-3">
            <Link className="text-light text-decoration-none" to="/">
              Home
            </Link>
            <Link className="text-light text-decoration-none" to="/login">
              Login
            </Link>
            <Link className="btn btn-purple px-3" to="/register">
              Register
            </Link>
          </div>
        </div>
      </nav>

      <section className="hero-section">
        <div className="container">
          <h1 className="display-4 fw-bold text-white mb-3">
            Find Your Dream Rental Property
          </h1>
          <p className="lead text-light mb-4">
            Comfort, Convenience &amp; Class — All in One Place
          </p>
        </div>
      </section>

      <section className="py-5">
        <div className="container text-center mb-4">
          <h2 className="fw-bold">Explore Our Premium Properties</h2>
          <p className="text-secondary">
            Looking to post your property?{" "}
            <Link to="/register" className="btn btn-outline-primary btn-sm ms-2">
              Register as Owner
            </Link>
          </p>
        </div>
        <AllPropertiesCards loggedIn={false} />
      </section>
    </div>
  );
};

export default Home;
