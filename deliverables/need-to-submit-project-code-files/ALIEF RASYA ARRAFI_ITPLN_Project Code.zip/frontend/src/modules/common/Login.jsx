import React, { useState, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import Toast from "./Toast";
import { UserContext } from "../../App";

const Login = () => {
  const navigate = useNavigate();
  const { setUserData, setUserLoggedIn } = useContext(UserContext);
  const [data, setData] = useState({
    email: "",
    password: "",
  });
  const [toast, setToast] = useState({ type: "", message: "" });

  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:8000/api/user/login", data);
      if (res.data.success) {
        localStorage.setItem("token", res.data.token);
        localStorage.setItem("user", JSON.stringify(res.data.user));
        setUserData(res.data.user);
        setUserLoggedIn(true);
        setToast({ type: "success", message: res.data.message });

        const userType = res.data.user.type;
        setTimeout(() => {
          if (userType === "Admin") {
            navigate("/adminhome");
          } else if (userType === "Owner") {
            navigate("/ownerhome");
          } else {
            navigate("/renterhome");
          }
        }, 800);
      } else {
        setToast({ type: "error", message: res.data.message });
      }
    } catch (error) {
      console.log(error);
      setToast({ type: "error", message: "Terjadi kesalahan saat login" });
    }
  };

  return (
    <div>
      <Toast
        type={toast.type}
        message={toast.message}
        onClose={() => setToast({ type: "", message: "" })}
      />
      <nav className="navbar navbar-expand-lg navbar-custom">
        <div className="container-fluid">
          <Link className="brand-title" to="/">
            RentEase
          </Link>
          <div className="d-flex align-items-center gap-3">
            <Link className="text-light text-decoration-none" to="/">
              Home
            </Link>
            <Link className="text-light text-decoration-none" to="/login">
              Login
            </Link>
            <Link className="btn btn-purple px-3" to="/register">
              Register
            </Link>
          </div>
        </div>
      </nav>

      <div className="container d-flex justify-content-center align-items-center" style={{ minHeight: "85vh" }}>
        <div className="card card-dark p-4 shadow" style={{ width: "100%", maxWidth: "420px" }}>
          <h3 className="text-center fw-bold mb-4">Sign In</h3>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <input
                type="email"
                name="email"
                required
                className="form-control form-control-dark"
                placeholder="Email Address"
                value={data.email}
                onChange={handleChange}
              />
            </div>
            <div className="mb-4">
              <input
                type="password"
                name="password"
                required
                className="form-control form-control-dark"
                placeholder="Password"
                value={data.password}
                onChange={handleChange}
              />
            </div>
            <button type="submit" className="btn btn-purple w-100 py-2">
              Sign In
            </button>
          </form>
          <div className="d-flex justify-content-between mt-3 small">
            <Link to="/forgotpassword" className="text-danger text-decoration-none">
              Forgot Password?
            </Link>
            <Link to="/register" className="text-primary text-decoration-none">
              Create an Account
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
