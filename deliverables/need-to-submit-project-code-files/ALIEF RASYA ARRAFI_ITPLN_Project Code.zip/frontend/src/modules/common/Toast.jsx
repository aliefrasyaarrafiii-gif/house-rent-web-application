import React, { useEffect } from "react";

const Toast = ({ type, message, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  if (!message) return null;

  return (
    <div
      style={{
        position: "fixed",
        top: "20px",
        right: "20px",
        zIndex: 9999,
        minWidth: "260px",
      }}
      className={`alert ${
        type === "success" ? "alert-success" : "alert-danger"
      } shadow-lg d-flex justify-content-between align-items-center`}
    >
      <span>{message}</span>
      <button type="button" className="btn-close ms-3" onClick={onClose}></button>
    </div>
  );
};

export default Toast;
