import React, { useState, useEffect } from "react";
import axios from "axios";

const AllProperty = () => {
  const [properties, setProperties] = useState([]);

  const getAllProperties = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get("http://localhost:8000/api/admin/getallproperties", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.data.success) {
        setProperties(res.data.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getAllProperties();
  }, []);

  return (
    <div className="table-responsive">
      <table className="table table-dark table-dark-custom">
        <thead>
          <tr>
            <th>Property ID</th>
            <th>Owner ID</th>
            <th>Property Type</th>
            <th>Property Ad Type</th>
            <th>Property Address</th>
            <th>Owner Contact</th>
            <th>Property Amt</th>
          </tr>
        </thead>
        <tbody>
          {properties.map((prop) => (
            <tr key={prop._id}>
              <td>{prop._id}</td>
              <td>{prop.ownerId}</td>
              <td>{prop.propertyType}</td>
              <td>{prop.propertyAdType}</td>
              <td>{prop.propertyAddress}</td>
              <td>{prop.ownerContact}</td>
              <td>Rp {Number(prop.propertyAmt).toLocaleString("id-ID")}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AllProperty;
