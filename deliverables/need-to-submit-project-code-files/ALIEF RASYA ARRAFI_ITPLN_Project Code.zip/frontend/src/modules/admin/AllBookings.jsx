import React, { useState, useEffect } from "react";
import axios from "axios";

const AllBookings = () => {
  const [bookings, setBookings] = useState([]);

  const getAllBookings = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get("http://localhost:8000/api/admin/getallbookings", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.data.success) {
        setBookings(res.data.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getAllBookings();
  }, []);

  return (
    <div className="table-responsive">
      <table className="table table-dark table-dark-custom">
        <thead>
          <tr>
            <th>Booking ID</th>
            <th>Owner ID</th>
            <th>Property ID</th>
            <th>Tenant ID</th>
            <th>Tenant Name</th>
            <th>Tenant Contact</th>
            <th>Booking Status</th>
          </tr>
        </thead>
        <tbody>
          {bookings.map((booking) => (
            <tr key={booking._id}>
              <td>{booking._id}</td>
              <td>{booking.ownerID}</td>
              <td>{booking.propertyId}</td>
              <td>{booking.userID}</td>
              <td>{booking.userName}</td>
              <td>{booking.phone}</td>
              <td>
                <span
                  className={
                    booking.bookingStatus === "booked"
                      ? "text-success fw-bold"
                      : "text-warning fw-bold"
                  }
                >
                  {booking.bookingStatus}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AllBookings;
