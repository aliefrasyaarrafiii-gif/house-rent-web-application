import React, { useState, useEffect } from "react";
import axios from "axios";
import Toast from "../common/Toast";

const AllUsers = () => {
  const [users, setUsers] = useState([]);
  const [toast, setToast] = useState({ type: "", message: "" });

  const getAllUsers = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get("http://localhost:8000/api/admin/getallusers", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.data.success) {
        setUsers(res.data.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getAllUsers();
  }, []);

  const handleStatusChange = async (userid, status) => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.post(
        "http://localhost:8000/api/admin/handlestatus",
        { userid, status },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (res.data.success) {
        setToast({ type: "success", message: res.data.message });
        getAllUsers();
      }
    } catch (error) {
      console.log(error);
      setToast({ type: "error", message: "Gagal mengubah status" });
    }
  };

  return (
    <div className="table-responsive">
      <Toast
        type={toast.type}
        message={toast.message}
        onClose={() => setToast({ type: "", message: "" })}
      />
      <table className="table table-dark table-dark-custom">
        <thead>
          <tr>
            <th>User ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Type</th>
            <th>Granted (Owners Only)</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user._id}>
              <td>{user._id}</td>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>{user.type}</td>
              <td>{user.type === "Owner" ? user.granted : "-"}</td>
              <td>
                {user.type === "Owner" &&
                  (user.granted === "ungranted" ? (
                    <button
                      className="btn btn-success btn-sm"
                      onClick={() => handleStatusChange(user._id, "granted")}
                    >
                      Grant
                    </button>
                  ) : (
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => handleStatusChange(user._id, "ungranted")}
                    >
                      Ungrant
                    </button>
                  ))}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AllUsers;
