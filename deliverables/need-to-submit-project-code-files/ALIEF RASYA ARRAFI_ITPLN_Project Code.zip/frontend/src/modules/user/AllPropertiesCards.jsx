import React, { useState, useEffect } from "react";
import axios from "axios";
import { Modal, Button, Form } from "react-bootstrap";
import Toast from "../common/Toast";

const AllPropertiesCards = ({ loggedIn }) => {
  const [allProperties, setAllProperties] = useState([]);
  const [filterPropertyType, setPropertyType] = useState("");
  const [filterPropertyAdType, setPropertyAdType] = useState("");
  const [filterPropertyAddress, setPropertyAddress] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState(null);
  const [userDetails, setUserDetails] = useState({
    fullName: "",
    phone: "",
  });
  const [toast, setToast] = useState({ type: "", message: "" });

  const getAllProperties = async () => {
    try {
      const res = await axios.get("http://localhost:8000/api/user/getAllProperties");
      if (res.data.success) {
        setAllProperties(res.data.data);
      }
    } catch (error) {
      console.log("Gagal memuat properti:", error);
    }
  };

  useEffect(() => {
    getAllProperties();
  }, []);

  const handleOpenModal = (property) => {
    setSelectedProperty(property);
    setShowModal(true);
  };

  const handleBookingSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");
      const res = await axios.post(
        `http://localhost:8000/api/user/bookinghandle/${selectedProperty._id}`,
        {
          userDetails,
          status: "pending",
          ownerId: selectedProperty.ownerId,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (res.data.success) {
        setToast({ type: "success", message: res.data.message });
        setShowModal(false);
        setUserDetails({ fullName: "", phone: "" });
      } else {
        setToast({ type: "error", message: res.data.message });
      }
    } catch (error) {
      console.log(error);
      setToast({ type: "error", message: "Gagal mengajukan booking" });
    }
  };

  const filteredProperties = allProperties
    .filter(
      (property) =>
        filterPropertyAddress === "" ||
        property.propertyAddress
          .toLowerCase()
          .includes(filterPropertyAddress.toLowerCase())
    )
    .filter(
      (property) =>
        filterPropertyAdType === "" ||
        property.propertyAdType
          .toLowerCase()
          .includes(filterPropertyAdType.toLowerCase())
    )
    .filter(
      (property) =>
        filterPropertyType === "" ||
        property.propertyType
          .toLowerCase()
          .includes(filterPropertyType.toLowerCase())
    );

  return (
    <div className="container my-4">
      <Toast
        type={toast.type}
        message={toast.message}
        onClose={() => setToast({ type: "", message: "" })}
      />

      <div className="row g-3 mb-4">
        <div className="col-md-5">
          <input
            type="text"
            className="form-control form-control-dark"
            placeholder="Search by Address..."
            value={filterPropertyAddress}
            onChange={(e) => setPropertyAddress(e.target.value)}
          />
        </div>
        <div className="col-md-3">
          <select
            className="form-select form-select-dark"
            value={filterPropertyAdType}
            onChange={(e) => setPropertyAdType(e.target.value)}
          >
            <option value="">All Ad Types</option>
            <option value="rent">Rent</option>
            <option value="sale">Sale</option>
          </select>
        </div>
        <div className="col-md-3">
          <select
            className="form-select form-select-dark"
            value={filterPropertyType}
            onChange={(e) => setPropertyType(e.target.value)}
          >
            <option value="">All Types</option>
            <option value="residential">Residential</option>
            <option value="commercial">Commercial</option>
          </select>
        </div>
      </div>

      <div className="row g-4">
        {filteredProperties.length > 0 ? (
          filteredProperties.map((property) => {
            const imageUrl =
              property.propertyImage && property.propertyImage.length > 0
                ? `http://localhost:8000${property.propertyImage[0].path}`
                : "https://images.unsplash.com/photo-1568605114967-8130f3a36994?auto=format&fit=crop&w=800&q=80";

            return (
              <div className="col-md-4" key={property._id}>
                <div className="card card-dark h-100 shadow-sm overflow-hidden">
                  <img
                    src={imageUrl}
                    alt="Property"
                    style={{ height: "200px", objectFit: "cover" }}
                    className="card-img-top"
                  />
                  <div className="card-body d-flex flex-column justify-content-between">
                    <div>
                      <h5 className="card-title fw-bold mb-1">
                        {property.propertyAddress}
                      </h5>
                      <p className="text-secondary small text-capitalize mb-2">
                        {property.propertyType} - {property.propertyAdType}
                      </p>
                      {loggedIn && (
                        <div className="small mb-3">
                          <p className="mb-1">
                            <strong>Owner:</strong> {property.ownerContact}
                          </p>
                          <p className="mb-1">
                            <strong>Availability:</strong>{" "}
                            <span
                              className={
                                property.isAvailable === "Available"
                                  ? "text-success"
                                  : "text-danger"
                              }
                            >
                              {property.isAvailable}
                            </span>
                          </p>
                          <p className="mb-0">
                            <strong>Price:</strong> Rp{" "}
                            {Number(property.propertyAmt).toLocaleString("id-ID")}
                          </p>
                        </div>
                      )}
                    </div>

                    <div>
                      {!loggedIn ? (
                        <span className="text-warning small fw-semibold">
                          Login to see details
                        </span>
                      ) : property.isAvailable === "Available" ? (
                        <button
                          className="btn btn-purple w-100 mt-2"
                          onClick={() => handleOpenModal(property)}
                        >
                          Get Info / Book
                        </button>
                      ) : (
                        <span className="text-danger small fw-semibold">
                          Not Available
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <p className="text-center text-secondary my-5">
            Belum ada properti yang tersedia saat ini.
          </p>
        )}
      </div>

      {selectedProperty && (
        <Modal
          show={showModal}
          onHide={() => setShowModal(false)}
          centered
          contentClassName="card-dark"
        >
          <Modal.Header closeButton closeVariant="white">
            <Modal.Title>Property Info &amp; Booking</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <p className="mb-1">
              <strong>Owner Name:</strong> {selectedProperty.ownerName}
            </p>
            <p className="mb-1">
              <strong>Contact:</strong> {selectedProperty.ownerContact}
            </p>
            <p className="mb-1">
              <strong>Address:</strong> {selectedProperty.propertyAddress}
            </p>
            <p className="mb-3">
              <strong>Additional Info:</strong>{" "}
              {selectedProperty.additionalInfo || "Tidak ada catatan tambahan"}
            </p>
            <hr className="border-secondary" />
            <Form onSubmit={handleBookingSubmit}>
              <Form.Group className="mb-3">
                <Form.Label>Your Full Name</Form.Label>
                <Form.Control
                  type="text"
                  required
                  className="form-control-dark"
                  placeholder="Masukkan nama lengkap"
                  value={userDetails.fullName}
                  onChange={(e) =>
                    setUserDetails({ ...userDetails, fullName: e.target.value })
                  }
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Your Phone Number</Form.Label>
                <Form.Control
                  type="text"
                  required
                  className="form-control-dark"
                  placeholder="Masukkan nomor HP / WhatsApp"
                  value={userDetails.phone}
                  onChange={(e) =>
                    setUserDetails({ ...userDetails, phone: e.target.value })
                  }
                />
              </Form.Group>
              <Button type="submit" className="btn-purple w-100">
                Book Property
              </Button>
            </Form>
          </Modal.Body>
        </Modal>
      )}
    </div>
  );
};

export default AllPropertiesCards;
