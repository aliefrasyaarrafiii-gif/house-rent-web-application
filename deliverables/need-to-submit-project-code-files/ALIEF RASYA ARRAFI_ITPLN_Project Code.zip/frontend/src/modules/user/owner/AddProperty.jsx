import React, { useState } from "react";
import axios from "axios";
import Toast from "../../common/Toast";

const AddProperty = () => {
  const [propertyDetails, setPropertyDetails] = useState({
    propertyType: "residential",
    propertyAdType: "rent",
    propertyAddress: "",
    ownerContact: "",
    propertyAmt: 0,
    additionalInfo: "",
  });
  const [image, setImage] = useState(null);
  const [toast, setToast] = useState({ type: "", message: "" });

  const handleChange = (e) => {
    setPropertyDetails({ ...propertyDetails, [e.target.name]: e.target.value });
  };

  const handleImageChange = (e) => {
    setImage(e.target.files);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("propertyType", propertyDetails.propertyType);
    formData.append("propertyAdType", propertyDetails.propertyAdType);
    formData.append("propertyAddress", propertyDetails.propertyAddress);
    formData.append("ownerContact", propertyDetails.ownerContact);
    formData.append("propertyAmt", propertyDetails.propertyAmt);
    formData.append("additionalInfo", propertyDetails.additionalInfo);

    if (image) {
      for (let i = 0; i < image.length; i++) {
        formData.append("propertyImages", image[i]);
      }
    }

    try {
      const token = localStorage.getItem("token");
      const res = await axios.post(
        "http://localhost:8000/api/owner/postproperty",
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      if (res.data.success) {
        setToast({ type: "success", message: res.data.message });
        setPropertyDetails({
          propertyType: "residential",
          propertyAdType: "rent",
          propertyAddress: "",
          ownerContact: "",
          propertyAmt: 0,
          additionalInfo: "",
        });
        setImage(null);
      } else {
        setToast({ type: "error", message: res.data.message });
      }
    } catch (error) {
      console.log(error);
      setToast({ type: "error", message: "Gagal menambahkan properti" });
    }
  };

  return (
    <div className="card card-dark p-4 shadow">
      <Toast
        type={toast.type}
        message={toast.message}
        onClose={() => setToast({ type: "", message: "" })}
      />
      <h4 className="text-center fw-bold text-primary mb-4">Add New Property</h4>
      <form onSubmit={handleSubmit}>
        <div className="row g-3 mb-3">
          <div className="col-md-4">
            <label className="form-label">Property Type</label>
            <select
              name="propertyType"
              className="form-select form-select-dark"
              value={propertyDetails.propertyType}
              onChange={handleChange}
            >
              <option value="residential">Residential</option>
              <option value="commercial">Commercial</option>
            </select>
          </div>
          <div className="col-md-4">
            <label className="form-label">Property Ad Type</label>
            <select
              name="propertyAdType"
              className="form-select form-select-dark"
              value={propertyDetails.propertyAdType}
              onChange={handleChange}
            >
              <option value="rent">Rent</option>
              <option value="sale">Sale</option>
            </select>
          </div>
          <div className="col-md-4">
            <label className="form-label">Property Full Address</label>
            <input
              type="text"
              name="propertyAddress"
              required
              className="form-control form-control-dark"
              placeholder="Address"
              value={propertyDetails.propertyAddress}
              onChange={handleChange}
            />
          </div>
        </div>

        <div className="row g-3 mb-3">
          <div className="col-md-4">
            <label className="form-label">Property Images</label>
            <input
              type="file"
              multiple
              accept="image/*"
              className="form-control form-control-dark"
              onChange={handleImageChange}
            />
          </div>
          <div className="col-md-4">
            <label className="form-label">Owner Contact No.</label>
            <input
              type="text"
              name="ownerContact"
              required
              className="form-control form-control-dark"
              placeholder="Contact number"
              value={propertyDetails.ownerContact}
              onChange={handleChange}
            />
          </div>
          <div className="col-md-4">
            <label className="form-label">Property Amount</label>
            <input
              type="number"
              name="propertyAmt"
              required
              className="form-control form-control-dark"
              value={propertyDetails.propertyAmt}
              onChange={handleChange}
            />
          </div>
        </div>

        <div className="mb-4">
          <label className="form-label">Additional Details for the Property</label>
          <textarea
            name="additionalInfo"
            rows="3"
            className="form-control form-control-dark"
            placeholder="Add any details here..."
            value={propertyDetails.additionalInfo}
            onChange={handleChange}
          ></textarea>
        </div>

        <div className="text-end">
          <button type="submit" className="btn btn-purple px-4">
            Submit Form
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddProperty;
