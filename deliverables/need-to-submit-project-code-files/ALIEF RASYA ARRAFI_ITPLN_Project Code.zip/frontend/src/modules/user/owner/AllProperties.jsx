import React, { useState, useEffect } from "react";
import axios from "axios";
import Toast from "../../common/Toast";

const AllProperties = () => {
  const [properties, setProperties] = useState([]);
  const [toast, setToast] = useState({ type: "", message: "" });

  const getOwnerProperties = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get("http://localhost:8000/api/owner/getallproperties", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.data.success) {
        setProperties(res.data.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getOwnerProperties();
  }, []);

  const handleDelete = async (propertyId) => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.delete(
        `http://localhost:8000/api/owner/deleteproperty/${propertyId}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (res.data.success) {
        setToast({ type: "success", message: res.data.message });
        getOwnerProperties();
      }
    } catch (error) {
      console.log(error);
      setToast({ type: "error", message: "Gagal menghapus properti" });
    }
  };

  const handleToggleAvailability = async (property) => {
    const newStatus = property.isAvailable === "Available" ? "Unavailable" : "Available";
    try {
      const token = localStorage.getItem("token");
      const res = await axios.patch(
        `http://localhost:8000/api/owner/updateproperty/${property._id}`,
        { isAvailable: newStatus },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (res.data.success) {
        setToast({ type: "success", message: res.data.message });
        getOwnerProperties();
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="table-responsive">
      <Toast
        type={toast.type}
        message={toast.message}
        onClose={() => setToast({ type: "", message: "" })}
      />
      <table className="table table-dark table-dark-custom">
        <thead>
          <tr>
            <th>Property ID</th>
            <th>Property Type</th>
            <th>Ad Type</th>
            <th>Address</th>
            <th>Owner Contact</th>
            <th>Amount</th>
            <th>Availability</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {properties.map((prop) => (
            <tr key={prop._id}>
              <td>{prop._id}</td>
              <td>{prop.propertyType}</td>
              <td>{prop.propertyAdType}</td>
              <td>{prop.propertyAddress}</td>
              <td>{prop.ownerContact}</td>
              <td>Rp {Number(prop.propertyAmt).toLocaleString("id-ID")}</td>
              <td>
                <span
                  className={
                    prop.isAvailable === "Available"
                      ? "text-success fw-bold"
                      : "text-danger fw-bold"
                  }
                >
                  {prop.isAvailable}
                </span>
              </td>
              <td>
                <div className="d-flex gap-2">
                  <button
                    className="btn btn-outline-info btn-sm"
                    onClick={() => handleToggleAvailability(prop)}
                  >
                    Toggle Status
                  </button>
                  <button
                    className="btn btn-outline-danger btn-sm"
                    onClick={() => handleDelete(prop._id)}
                  >
                    Delete
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AllProperties;
