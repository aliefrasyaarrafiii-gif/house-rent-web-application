import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { UserContext } from "../../../App";
import AddProperty from "./AddProperty";
import AllProperties from "./AllProperties";
import AllBookings from "./AllBookings";

const OwnerHome = () => {
  const navigate = useNavigate();
  const { userData, setUserData, setUserLoggedIn } = useContext(UserContext);
  const [activeTab, setActiveTab] = useState("add");

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setUserData(null);
    setUserLoggedIn(false);
    navigate("/login");
  };

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-custom">
        <div className="container-fluid">
          <span className="brand-title">RentEase</span>
          <div className="d-flex align-items-center gap-3">
            <span className="text-light">Hi, {userData?.name}</span>
            <button onClick={handleLogout} className="btn btn-danger btn-sm">
              Log Out
            </button>
          </div>
        </div>
      </nav>

      <div className="container my-4">
        {userData?.granted === "ungranted" ? (
          <div className="alert alert-warning text-center my-5">
            Akun Owner Anda masih menunggu persetujuan (Grant) dari Admin sebelum dapat menambahkan properti.
          </div>
        ) : (
          <>
            <ul className="nav nav-tabs mb-4">
              <li className="nav-item">
                <button
                  className={`nav-link ${activeTab === "add" ? "active" : ""}`}
                  onClick={() => setActiveTab("add")}
                >
                  Add Property
                </button>
              </li>
              <li className="nav-item">
                <button
                  className={`nav-link ${activeTab === "properties" ? "active" : ""}`}
                  onClick={() => setActiveTab("properties")}
                >
                  All Properties
                </button>
              </li>
              <li className="nav-item">
                <button
                  className={`nav-link ${activeTab === "bookings" ? "active" : ""}`}
                  onClick={() => setActiveTab("bookings")}
                >
                  All Bookings
                </button>
              </li>
            </ul>

            {activeTab === "add" && <AddProperty />}
            {activeTab === "properties" && <AllProperties />}
            {activeTab === "bookings" && <AllBookings />}
          </>
        )}
      </div>
    </div>
  );
};

export default OwnerHome;
