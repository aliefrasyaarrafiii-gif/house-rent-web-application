import React, { useState, useEffect } from "react";
import axios from "axios";
import Toast from "../../common/Toast";

const AllBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [toast, setToast] = useState({ type: "", message: "" });

  const getOwnerBookings = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get("http://localhost:8000/api/owner/getallbookings", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.data.success) {
        setBookings(res.data.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getOwnerBookings();
  }, []);

  const handleBookingStatus = async (bookingId, propertyId, status) => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.post(
        "http://localhost:8000/api/owner/handlebookingstatus",
        { bookingId, propertyId, status },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (res.data.success) {
        setToast({ type: "success", message: res.data.message });
        getOwnerBookings();
      }
    } catch (error) {
      console.log(error);
      setToast({ type: "error", message: "Gagal mengubah status booking" });
    }
  };

  return (
    <div className="table-responsive">
      <Toast
        type={toast.type}
        message={toast.message}
        onClose={() => setToast({ type: "", message: "" })}
      />
      <table className="table table-dark table-dark-custom">
        <thead>
          <tr>
            <th>Booking ID</th>
            <th>Property ID</th>
            <th>Tenant Name</th>
            <th>Tenant Phone</th>
            <th>Booking Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {bookings.map((booking) => (
            <tr key={booking._id}>
              <td>{booking._id}</td>
              <td>{booking.propertyId}</td>
              <td>{booking.userName}</td>
              <td>{booking.phone}</td>
              <td>
                <span
                  className={
                    booking.bookingStatus === "booked"
                      ? "text-success fw-bold"
                      : "text-warning fw-bold"
                  }
                >
                  {booking.bookingStatus}
                </span>
              </td>
              <td>
                {booking.bookingStatus === "pending" ? (
                  <button
                    className="btn btn-success btn-sm"
                    onClick={() =>
                      handleBookingStatus(booking._id, booking.propertyId, "booked")
                    }
                  >
                    Mark Booked
                  </button>
                ) : (
                  <button
                    className="btn btn-warning btn-sm"
                    onClick={() =>
                      handleBookingStatus(booking._id, booking.propertyId, "pending")
                    }
                  >
                    Mark Pending
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AllBookings;
