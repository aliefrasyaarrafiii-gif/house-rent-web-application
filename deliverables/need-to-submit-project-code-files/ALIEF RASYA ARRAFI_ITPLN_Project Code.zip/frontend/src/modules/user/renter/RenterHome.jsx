import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { UserContext } from "../../../App";
import AllPropertiesCards from "../AllPropertiesCards";
import AllProperties from "./AllProperties";

const RenterHome = () => {
  const navigate = useNavigate();
  const { userData, setUserData, setUserLoggedIn } = useContext(UserContext);
  const [activeTab, setActiveTab] = useState("properties");

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setUserData(null);
    setUserLoggedIn(false);
    navigate("/login");
  };

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-custom">
        <div className="container-fluid">
          <span className="brand-title">RentEase</span>
          <div className="d-flex align-items-center gap-3">
            <span className="text-light">Hi, {userData?.name}</span>
            <button onClick={handleLogout} className="btn btn-danger btn-sm">
              Log Out
            </button>
          </div>
        </div>
      </nav>

      <div className="container my-4">
        <ul className="nav nav-tabs mb-4">
          <li className="nav-item">
            <button
              className={`nav-link ${activeTab === "properties" ? "active" : ""}`}
              onClick={() => setActiveTab("properties")}
            >
              All Properties
            </button>
          </li>
          <li className="nav-item">
            <button
              className={`nav-link ${activeTab === "history" ? "active" : ""}`}
              onClick={() => setActiveTab("history")}
            >
              Booking History
            </button>
          </li>
        </ul>

        {activeTab === "properties" && <AllPropertiesCards loggedIn={true} />}
        {activeTab === "history" && <AllProperties />}
      </div>
    </div>
  );
};

export default RenterHome;
