import React, { useState, useEffect } from "react";
import axios from "axios";

const AllProperties = () => {
  const [bookings, setBookings] = useState([]);

  const getAllBookings = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get("http://localhost:8000/api/user/getallbookings", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.data.success) {
        setBookings(res.data.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getAllBookings();
  }, []);

  return (
    <div className="card card-dark p-4 shadow">
      <h5 className="text-primary fw-bold mb-3">All My Bookings</h5>
      <div className="table-responsive">
        <table className="table table-dark table-dark-custom">
          <thead>
            <tr>
              <th>Booking ID</th>
              <th>Property ID</th>
              <th>Tenant Name</th>
              <th>Phone</th>
              <th>Booking Status</th>
            </tr>
          </thead>
          <tbody>
            {bookings.length > 0 ? (
              bookings.map((booking) => (
                <tr key={booking._id}>
                  <td>{booking._id}</td>
                  <td>{booking.propertyId}</td>
                  <td>{booking.userName}</td>
                  <td>{booking.phone}</td>
                  <td>
                    <span
                      className={
                        booking.bookingStatus === "booked"
                          ? "text-success fw-bold"
                          : "text-warning fw-bold"
                      }
                    >
                      {booking.bookingStatus}
                    </span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="text-center text-secondary">
                  Belum ada riwayat booking.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AllProperties;
